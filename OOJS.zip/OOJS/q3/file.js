window.onload = function() {

    //using bind()

    var x = {name : "Abc"};
    var greet1 = function(a,b,c) {
        return "Welcome " + this.name + " to " + a + " " + b + " in " + c;
    };
    var msg = greet1.bind(x); 
    document.getElementById("c1").innerHTML = msg("TTN","NCR","India"); 
    
    //using call()

    var y = {name : "Def"};
    var greet2 = function(a,b,c) {
        return "Welcome " + this.name + " to " + a + " " + b + " in " + c;
    };
    document.getElementById("c2").innerHTML = greet2.call(y, "TTN", "NCR", "India");
}