window.onload = function() {
    var instance = 0;
	var invoke = 0;
	function test(){
		if(this === window){
			invoke++;
		}
		else{
			instance++;
		}
	}
	test();
	document.getElementById("msg1").innerHTML = "When function is called without using new keyword : ";
	document.getElementById("count1").innerHTML = "Instance count is : " + instance + ", Invoke count is : " + invoke;
    new test();
	document.getElementById("msg2").innerHTML = "When function is called by using new keyword : ";
	document.getElementById("count2").innerHTML = "Instance count is : " + instance + ", Invoke count is : " + invoke;
}