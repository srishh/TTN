window.onload = function() {
    function counter() {
        let count = 1;
        return function() {
            count++;
            document.getElementById("count").innerHTML = count;
        }
    }
    var x = counter();
    document.getElementById("msg").innerHTML = "Counter is increased by 1, count is : ";
    x();
}