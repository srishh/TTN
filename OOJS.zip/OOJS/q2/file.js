window.onload = function() {
    var arr = new Array(1,2,3,4,5);
    function print(x) {
        var i = 0;
        var p = setInterval(function() {
            if(i > x.length) {
                clearInterval(p);
            }
            else {
                var element = document.createTextNode(x[i++]);
                var div = document.createElement("div");
                div.appendChild(element);
                document.getElementById("content").appendChild(div);
            }
        }, 3000);
    }
    print(arr);
}