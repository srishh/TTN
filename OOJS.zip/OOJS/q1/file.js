window.onload = function() {
    function person() {
    this.fname = "Abc";
    this.lname = "Def";
    }
    function employee() {
        this.empID = 111;
        this.salary = 50000;
    }
    function developer() {
        this.competency = "MEAN";
        this.project = "SAMPLE";
    }
    employee.prototype = new person();
    developer.prototype = new employee();
    var info = new developer();
    document.getElementById("fname").innerHTML = "First Name : " + info.fname;
    document.getElementById("lname").innerHTML = "Last Name : " + info.lname;
    document.getElementById("empID").innerHTML = "Employee ID : " + info.empID;
    document.getElementById("salary").innerHTML = "Salary : " + info.salary;
    document.getElementById("competency").innerHTML = "Competency : " + info.competency;
    document.getElementById("project").innerHTML = "Project : " + info.project;
}