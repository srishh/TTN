window.onload = function() {
   function factorial(){
      return [1, 2, 3, 4, 5].map(function(n) {
         return (n <= 1) ? 1 : arguments.callee(n - 1) * n;
      });
   }
   document.getElementById("p1").innerHTML = "Factorial using arguments.callee : " + factorial();
   
   function average(){
      var sum = 0;
      for(let elem of arguments) {
         sum+=elem;
      }
      return sum/arguments.length;
   }
   document.getElementById("p2").innerHTML = "Average using arguments.length : " + average(2,2);
   
   function sum(){
      var sum=0;
      for(let elem of arguments){
         sum+=elem;
      }
      return sum;
   }
   document.getElementById("p3").innerHTML = "Sum of arguments by iterating the arguments : " + sum(1,2,3);
}