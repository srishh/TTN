function result() {
    var arr = [3,62,234,7,23,74,23,76,92];
    console.log(arr);
    var arr2 = arr.filter(e => {
        if(e > 70)
            return e;
    });
    console.log("Array elements greater than 70 : " + arr2);
}