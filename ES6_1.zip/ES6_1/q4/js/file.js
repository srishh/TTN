function result() {
	const user = {
            firstName : "Sahil",
            lastName : "Dua",
            Address : {
                Line1 : "address line 1",
                Line2 : "address line 2",
                State : "Delhi",
                Pin : 110085,
                Country : "India",
                City : "New Delhi"
            },
            phoneNo : 9999999999
        }
    let {Line1 : addressLine1, Line2, State, Pin, Country, City} = user.Address
    var addr = 
                `line1 = ${addressLine1}
                 line2 = ${Line2}
                 state = ${State}
                 pin = ${Pin}
                 country = ${Country}
                 city = ${City}`
    document.querySelector("#result").innerText = addr;
    console.log(addr);
}