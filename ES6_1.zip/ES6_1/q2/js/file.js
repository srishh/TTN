function question2() {
	let list = document.querySelectorAll("li");
	var arr1 = [];
	for(let a = 0; a < list.length; a++) {
	  arr1.push(list[a]);
	};
	return arr1;
}

function question2_1() {
	var arr1 = question2();
	console.log(arr1); 
}

function question2_2() {
	var arr1 = question2();
	var arr2 = arr1.filter(value => {
	    if(value.innerHTML.split(" ")[0] == "Flexbox")
            return value;
	});
	console.log(arr2);
}

function question2_3() {
	var array = question2();
	var list = array.map( element => {
            return element.getAttribute("data-time");
        });
    console.log(list);
}

function question2_4() {
	var array = question2();
	var second = array.map(element => {
            return parseInt(element.getAttribute("data-time").split(":")[1]);
        })
    console.log(second);
}

function question2_5() {
	var array = question2();
	var list = array.map(element => {
            return element.getAttribute("data-time");
        });
	var sumSecond = list.reduce((accumulator,ele) => {
            let sec = parseInt(ele.split(":")[1]);
            let min = parseInt(ele.split(":")[0])*60;
            return accumulator + sec + min;
        },0)
        console.log("second sum: ", sumSecond);
        var sumHour = Math.round(sumSecond/3600);
        sumSecond = sumSecond%3600;
        var sumMinute = Math.round(sumSecond/60);
        sumSecond = Math.round(sumSecond%60);
        console.log(`Total Time : ${sumHour}:${sumMinute}:${sumSecond}`);
}