function result(){
    const song = {
           name : 'Dying to live',
           artist : 'Tupac',
           featuring : 'Biggie Smalls'
       };
       document.querySelector("#result").innerText = `${song.name} - ${song.artist}
       (Featuring ${song.featuring})`
}