function q1() {
    var arr = [1,2,2,3,4,4,4,5,6,7,7,8,9,9,9]
    var ele = Array.from(new Set(arr))
    console.log(ele);
}

function q2() {
    let map_index = 0;
    let findCombo = function combo(map,str,l,r) {
        if(l == r) {
            map_index++;
            insertInToMap(map,map_index,str);
        }
        else {
            for(let i = l; i <= r; i++) {
                str = swap(str,l,i);
                combo(map,str,l+1,r); 
	            str = swap(str,l,i);      
            }
        }
    }
    let swap = function (a,i,j) { 
	 	let strToArr = a.split('');
		temp = strToArr[i]; 
		strToArr[i] = strToArr[j];
		strToArr[j] = temp; 
		return strToArr.join('');
	} 
    let insertInToMap = function (map,key,value) {
        map.set(key,value);
    } 
    let map = new Map();
    findCombo(map,"abc",0,2);
    console.log(map);
}

function q3() {
    class Person {
        fname = "";
        lname = "";
        constructor(fname,lname) {
            this.fname = "Abc";
            this.lname = "Def";
        }
        static printPerson() {
            console.log("Person's details recorded.");
        }
    }
    class Employee extends Person {
        empID = 0;
        salary = 0;
        constructor(fname,lname,empID,salary) {
            super(fname,lname);
            this.empID = 111;
            this.salary = 50000;
        }
        static printEmp() {
            Person.printPerson();
            console.log("Employee's details recorded.");
        }
    }
    class Developer extends Employee {
        competency = "";
        project = "";
        constructor(fname,lname,empID,salary,competency,project) {
            super(fname,lname,empID,salary);
            this.competency = "MEAN";
            this.project = "SAMPLE";
        }
        static printDev() {
            Employee.printEmp();
            console.log("Developer's details recorded.");
        }
    }
    let x = new Developer();
    console.log(x.fname);
    console.log(Developer.printEmp());
    console.log(x.competency);
}

function q4() {
    class Test{
        fn() {  
            console.log("Success");
        }
        static operation() {
            let a = 7;
            let b = 5;
            console.log("Multiplication of the two numbers : " + a * b);
        }
    }
    Test.operation();
    var c = new Test();
    c.fn();
}

function q7() {
    let flatten = (arr) => {
        var array = [];
        while(arr.length) {
            var value = arr.shift();
            if(Array.isArray(value)) {
                arr = value.concat(arr);
            }
            else {
                array.push(value);
            }
        }
        return array;
    }
    console.log(flatten([1,2,3,[5,6,7,[4,5,6],7], 23,76, [45,67]]));
}

function q8() {
    class Node {
        constructor(value) {
          this.data = value;
          this.next = null;
        }
    }   
    class LinkedList {
        constructor(value) {
            this.head = new Node(value);
            this.tail = this.head;
        }
        addFirst(value) {
            console.log(this.head);
            let new_node = new Node(value);
            new_node.next = this.head;
            this.head = new_node;
            console.log(this.head);
        }
        addLast(value) {
            let new_node = new Node(value);
            this.tail.next = new_node;
            this.tail = new_node;
        }
        length() {
            let temp_head = this.head;
            let length = 0;
            while(temp_head.next != null) {
                length++;
                temp_head = temp_head.next;
            }
            return length;
        }
        getFirst() {
            return this.head;
        }
        getLast() {
            return this.tail;
        }
        toString = () => {
            let temp_head = this.head;
            let str = '';
            while(temp_head != null) {
                str += `${temp_head.data}`;
                if(temp_head.next != null) {
                    str+=` ---> `
                }
                temp_head = temp_head.next;
            }
            return str;
        }
    }
    let my_linkedList = new LinkedList(1);
    my_linkedList.addFirst(2);
    my_linkedList.addFirst(3);
    my_linkedList.addFirst(4);
    my_linkedList.addFirst(5);
    my_linkedList.addFirst('START');
    my_linkedList.addLast("END");
    console.log(my_linkedList + '');
    console.log(my_linkedList.getFirst());
    console.log(my_linkedList.getLast());
}

function q9() {
    var map = new Map();
    map.set("First Name", "Srishti"); 
    map.set("Last Name", "Sharma"); 
    map.set("Competency", "MEAN");
    console.log(map);
}

function q10() {
    class Stack {     
        constructor() {         
            this.items = [];
        } 
        push(element) {     
            this.items.push(element);
        } 
        pop() {    
            if (this.items.length == 0) 
                return "Underflow"; 
            else
                return this.items.pop(); 
        } 
        peek() {    
            return this.items[this.items.length - 1];
        } 
        printStack() { 
            var str = ""; 
            for (var i = 0; i < this.items.length; i++) 
                str += this.items[i] + " "; 
            return str; 
        } 
    }
    var stack = new Stack();
    stack.push(100); 
    stack.push(200); 
    stack.push(300);
    console.log("Elements of stack are : " + stack.printStack()); 
    console.log("Last element of stack : " + stack.peek());
    console.log("Element removed : " + stack.pop());
    console.log("Elements of stack after pop() operation : " + stack.printStack());
}