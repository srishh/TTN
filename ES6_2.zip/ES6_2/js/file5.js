window.onload = function() {
    const pie = 3.14159;
    let circle = () =>
    {
        let radius = 3;
        return pie * radius * radius;
    }
    let rectangle = () =>
    {
        let length = 7;
        let breadth = 5;
        return length * breadth;
    }
    let cylinder = () =>
    {
        let radius = 5;
        let height = 7;
        return 2 * pie * radius * (height + radius);
    }
    document.getElementById("circle").innerHTML = "Area of circle of radius : 3 => " + circle();
    document.getElementById("rectangle").innerHTML = "Area of rectangle of length : 7 and breadth : 5 => " + rectangle();
    document.getElementById("cylinder").innerHTML = "Area of cylinder of radius : 5 and height : 7 =>" + cylinder();
}